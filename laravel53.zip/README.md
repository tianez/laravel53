# laravel53
laravel53

php artisan make:migration create_users_table

php artisan make:seeder article_category
php artisan migrate
php artisan migrate:refresh --seed


php artisan db:seed --class=UserTableSeeder


php artisan make:controller PhotoController --resource

php artisan make:model User

php artisan make:model User -m