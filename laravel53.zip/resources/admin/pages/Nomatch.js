'use strict'
class Nomatch extends React.Component {
    constructor() {
        super()
    }
    render() {
        return (
            React.createElement('h3', null, 'Nomatch')
        )
    }
}
module.exports = Nomatch
