 <?php $__env->startSection('title', 'Page Title'); ?> <?php $__env->startSection('content'); ?>
<div class="weui_btn_area">
  <div class="weui_btn weui_btn_primary">查询结果</div>
</div>
<section class='result'>
  <table class="table table-bordered">
    <tbody>
      <tr>
        <td>你的姓名</td>
        <td><?php echo e($user->tj_name); ?></td>
        <td>身份证号</td>
        <td><?php echo e((isset($user->china_id) && $user->china_id!=='') ? $user->china_id : '暂无'); ?></td>
      </tr>
      <tr>
        <td>体检单号</td>
        <td><?php echo e($user->tj_id); ?></td>
        <td>手机号码</td>
        <td><?php echo e(isset($user->mobile_phone) ? $user->mobile_phone : '暂无'); ?></td>
      </tr>
      <tr>
        <td>体检日期</td>
        <td>2015-08-21 14:53:02</td>
        <td>报告日期</td>
        <td></td>
      </tr>
    </tbody>
  </table>
</section>
<div class="weui_btn_area">
  <a href="logout" class="weui_btn weui_btn_primary">退出登录</a>
</div>
<section class='result'>
  <table class="table table-bordered">
    <tr>
      <th>体检项目</th>
      <th>详细报告</th>
    </tr>
    <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $r): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <tr>
      <td><?php echo e($key); ?></td>
      <td><?php echo $r; ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  </table>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('healthy.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>