  <?php $__env->startSection('content'); ?>
<div class="list">
    <div class="weui_tab">
      <img src="/front/images/report/list01.png" class="top"></img>
      <div class="weui_navbar">
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <?php if($cur->id ==$cat->id): ?> 
        <div class="weui_navbar_item weui_bar_item_on">
          <?php echo e($cat->category_name); ?>

        </div>
        <?php else: ?>
        <a href="<?php echo e($cat->id); ?>" class="weui_navbar_item">
          <?php echo e($cat->category_name); ?>

        </a>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </div>
      <div class="weui_tab_bd">
      <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <a href="/show/<?php echo e($d['id']); ?>" class="weui_media_box weui_media_appmsg">
            <?php if(isset($d['thumb'])): ?>
            <?php $thumb = json_decode($d['thumb']); ?>
            <div class="weui_media_hd">
                <img class="weui_media_appmsg_thumb" src="<?php echo e($thumb[0]); ?>" alt="">
            </div>
            <?php endif; ?>
            <div class="weui_media_bd">
                <h4 class="weui_media_title"><?php echo e($d['title']); ?></h4>
                <p class="weui_media_desc"><span><?php echo e($d['created_at']); ?></span><span class='view'>浏览<?php echo e($d['view']); ?>次</span></p>
            </div>
          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>