 <?php $__env->startSection('content'); ?>
<div class="header">
    <a onclick="window.history.back()" class="icon icon-left"></a>
    <h1><?php echo e($data['category']); ?></h1>
</div>
<div class="content">
  <div class="article">
    <div class="article_title"><?php echo e($data['title']); ?></div>
    <div class="article_dec"><span>时间： <?php echo e($data['created_at']); ?></span><span>浏览：<?php echo e($data['view']); ?></span></div>
    <div class="article_hr"></div>
    <div class="article_content">
      <?php echo $data['content']; ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('report.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>